# Banner Correlator v0.3.0 (Authorized Inventory & Hygiene Auditor)

A modular, asynchronous Python utility for authorized asset inventory, service banner inspection, TLS certificate hygiene checks, and local advisory correlation.

## Legal Notice & Disclaimer
This software is intended strictly for authorized system administration, defensive asset auditing, and educational laboratory environments where you have explicit permission to inspect targets. **The author assumes no liability or responsibility for any misuse, unauthorized access, or damage caused by this software.**

## Architecture
- `banner_correlator/cli.py`: CLI parser, progress output, and orchestration.
- `banner_correlator/scanner.py`: Async TCP, TLS, and basic UDP inspection with concurrency, jitter, and RTT measurement.
- `banner_correlator/parsers.py`: Banner product/version extraction, HTTP security header hygiene, and hex preview formatting.
- `banner_correlator/rules.py`: Multi-file rule loader, operator-based version comparator, ignore list filtering, and compliance scoring.
- `banner_correlator/reporter.py`: Terminal table, JSON, Markdown, CSV, standalone HTML report generation, and scan diff engine.
- `banner_correlator/storage.py`: SQLite scan history persistence.
- `banner_correlator/config.py`: JSON configuration loader and target/port expansion utilities.
- `banner_correlator/mock_server.py`: Local loopback test server for safe verification in Termux or CI.

## Quick Start (Termux / Linux)
```bash
pkg update && pkg install -y python unzip
unzip banner-correlator-v3.zip -d ~/
cd ~/banner-correlator-v3
python -m unittest discover -s tests
python correlator.py --host 127.0.0.1 --ports 22,80,443 --format table
```
