import re
from typing import Any

PRODUCT_PATTERNS: list[tuple[str, str]] = [
    ("OpenSSH", r"\bOpenSSH[_\s/-]+v?(\d+(?:\.\d+){0,3}(?:p\d+)?)\b"),
    ("nginx", r"\bnginx[_\s/-]+v?(\d+(?:\.\d+){0,3})\b"),
    ("Apache", r"\bApache(?:\s+HTTP\s+Server)?[_\s/-]+v?(\d+(?:\.\d+){0,3})\b"),
    ("PostgreSQL", r"\bPostgreSQL[_\s/-]+v?(\d+(?:\.\d+){0,3})\b"),
    ("MariaDB", r"\bMariaDB[_\s/-]+v?(\d+(?:\.\d+){0,3})\b"),
    ("MySQL", r"\bMySQL[_\s/-]+v?(\d+(?:\.\d+){0,3})\b"),
    ("Redis", r"\bredis_version:(\d+(?:\.\d+){0,3})\b"),
    ("Postfix", r"\bPostfix(?:\s*\([^)]*\))?[_\s/-]*v?(\d+(?:\.\d+){0,3})?"),
    ("ProFTPD", r"\bProFTPD[_\s/-]+v?(\d+(?:\.\d+){0,3}[a-z]?)\b"),
]

SECURITY_HEADERS = [
    "strict-transport-security",
    "content-security-policy",
    "x-frame-options",
    "x-content-type-options",
    "referrer-policy",
]


def parse_version_tuple(raw: str) -> tuple[int, ...]:
    nums = [int(x) for x in re.findall(r"\d+", raw)]
    if not nums:
        raise ValueError(f"No numeric version components found in {raw!r}")
    return tuple(nums)


def normalize_tuple(ver: tuple[int, ...], length: int = 4) -> tuple[int, ...]:
    if len(ver) >= length:
        return ver[:length]
    return ver + (0,) * (length - len(ver))


def detect_product(banner: str) -> dict[str, Any] | None:
    if not banner:
        return None
    for product, pattern in PRODUCT_PATTERNS:
        match = re.search(pattern, banner, re.IGNORECASE)
        if match:
            raw_ver = match.group(1) if match.lastindex else None
            ver_tuple = parse_version_tuple(raw_ver) if raw_ver else ()
            return {
                "product": product,
                "raw_version": raw_ver or "unknown",
                "version_tuple": ver_tuple,
            }
    return None


def analyze_http_headers(raw_response: str) -> dict[str, Any]:
    if not raw_response.startswith("HTTP/"):
        return {"is_http": False}
    lines = raw_response.splitlines()
    status_line = lines[0].strip() if lines else ""
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if not line.strip():
            break
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()

    missing = [h for h in SECURITY_HEADERS if h not in headers]
    disclosures: dict[str, str] = {}
    for key in ("server", "x-powered-by", "x-aspnet-version"):
        if key in headers:
            disclosures[key] = headers[key]

    return {
        "is_http": True,
        "status": status_line,
        "missing_security_headers": missing,
        "disclosures": disclosures,
    }


def format_banner_preview(raw_bytes: bytes, max_chars: int = 280) -> tuple[str, str]:
    text = raw_bytes.decode("utf-8", errors="replace").strip()
    compact = " ".join(text.splitlines())[:max_chars]
    hex_preview = raw_bytes[:64].hex()
    return compact, hex_preview
