import argparse
import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import PORT_PROFILES, expand_targets, load_config, parse_ports
from .reporter import (
    diff_reports,
    mask_host,
    render_csv,
    render_html,
    render_markdown,
    render_table,
)
from .rules import compute_hygiene_score, evaluate_findings, load_rules
from .scanner import probe_tcp_port, probe_udp_port_sync
from .storage import save_to_sqlite


async def execute_scan(
    targets: list[str],
    ports: list[int],
    rules: list[dict[str, Any]],
    ignore_list: list[dict[str, Any]],
    timeout: float,
    concurrency: int,
    jitter_ms: int,
    udp_ports: list[int],
    do_mask: bool,
    show_progress: bool,
) -> dict[str, Any]:
    sem = asyncio.Semaphore(concurrency)
    total_tasks = len(targets) * (len(ports) + len(udp_ports))
    completed = 0
    results: list[dict[str, Any]] = []

    async def inspect_one(host: str, port: int, is_udp: bool = False) -> dict[str, Any]:
        nonlocal completed
        async with sem:
            if is_udp:
                raw = await asyncio.to_thread(probe_udp_port_sync, host, port, timeout)
            else:
                raw = await probe_tcp_port(host, port, timeout=timeout, jitter_ms=jitter_ms)

            if raw["state"] == "open":
                eval_res = evaluate_findings(
                    host=host,
                    port=port,
                    banner=raw.get("banner", ""),
                    http_info=raw.get("http", {}),
                    tls_info=raw.get("tls", {}),
                    rules=rules,
                    ignore_list=ignore_list,
                )
            else:
                eval_res = {"detected": None, "matches": [], "recommendations": []}

            raw["host"] = mask_host(host) if do_mask else host
            raw.update(eval_res)
            completed += 1
            if show_progress:
                pct = int((completed / max(1, total_tasks)) * 100)
                print(f"\rProgress: {completed}/{total_tasks} ({pct}%)", end="", file=sys.stderr)
            return raw

    tasks = []
    for host in targets:
        for port in ports:
            tasks.append(inspect_one(host, port, is_udp=False))
        for uport in udp_ports:
            tasks.append(inspect_one(host, uport, is_udp=True))

    results = await asyncio.gather(*tasks)
    if show_progress and total_tasks > 0:
        print("", file=sys.stderr)

    results.sort(key=lambda r: (r["host"], r.get("protocol", "tcp"), r["port"]))
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "targets_checked": len(targets),
        "hygiene_score": compute_hygiene_score(results),
        "results": results,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Banner Correlator - Authorized Asset Inventory & Hygiene Auditor"
    )
    parser.add_argument("--host", action="append", help="Authorized host, IP, or CIDR (repeatable)")
    parser.add_argument("--targets-file", type=Path, help="File with newline-separated targets")
    parser.add_argument("--ports", help="Comma-separated TCP ports/ranges (e.g. 22,80,8000-8002)")
    parser.add_argument("--udp-ports", default="", help="Optional comma-separated UDP ports (e.g. 53)")
    parser.add_argument("--profile", choices=sorted(PORT_PROFILES.keys()), help="Preset TCP port profile")
    parser.add_argument("--timeout", type=float, help="Socket timeout in seconds (default 2.0)")
    parser.add_argument("--concurrency", type=int, help="Max concurrent probes (default 25)")
    parser.add_argument("--jitter-ms", type=int, help="Max random delay in ms before each probe")
    parser.add_argument("--rules", action="append", help="Path to advisory rules JSON (repeatable)")
    parser.add_argument("--validate-rules", action="store_true", help="Validate rule files and exit")
    parser.add_argument("--config", type=Path, help="Optional JSON configuration file")
    parser.add_argument("--format", choices=["table", "json", "md", "csv", "html"], default="table")
    parser.add_argument("--output", type=Path, help="Write report to file")
    parser.add_argument("--sqlite", type=Path, help="Persist scan history to SQLite database")
    parser.add_argument("--diff", type=Path, help="Compare results against a previous JSON report")
    parser.add_argument("--only-matches", action="store_true", help="Only display rows with findings")
    parser.add_argument("--mask-hosts", action="store_true", help="Mask target IP octets in output")
    parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors")
    parser.add_argument("--progress", action="store_true", help="Show progress indicator on stderr")
    parser.add_argument("--fail-on-findings", action="store_true", help="Exit with code 1 if advisories match")
    args = parser.parse_args(argv)

    try:
        cfg = load_config(args.config)
        root_dir = Path(__file__).resolve().parent.parent
        raw_rules = args.rules or cfg.get("rules") or ["cve_rules.json"]
        rule_paths = [
            Path(r) if Path(r).is_absolute() else (root_dir / r) for r in raw_rules
        ]
        rules = load_rules(rule_paths)
        if args.validate_rules:
            print(f"Validated {len(rules)} rules successfully.")
            return 0

        targets = expand_targets(args.host, args.targets_file)
        ports = parse_ports(args.ports or cfg.get("ports"), profile=args.profile)
        udp_ports = parse_ports(args.udp_ports) if args.udp_ports.strip() else []
        timeout = args.timeout if args.timeout is not None else float(cfg.get("timeout", 2.0))
        concurrency = args.concurrency if args.concurrency is not None else int(cfg.get("concurrency", 25))
        jitter_ms = args.jitter_ms if args.jitter_ms is not None else int(cfg.get("jitter_ms", 0))
        if timeout <= 0 or concurrency < 1 or jitter_ms < 0:
            raise ValueError("Invalid timeout, concurrency, or jitter value.")
        ignore_list = cfg.get("ignore", [])
        do_mask = args.mask_hosts or bool(cfg.get("mask_hosts", False))
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(f"Configuration/Input error: {exc}", file=sys.stderr)
        return 2

    report = asyncio.run(
        execute_scan(
            targets=targets,
            ports=ports,
            rules=rules,
            ignore_list=ignore_list,
            timeout=timeout,
            concurrency=concurrency,
            jitter_ms=jitter_ms,
            udp_ports=udp_ports,
            do_mask=do_mask,
            show_progress=args.progress,
        )
    )

    if args.format == "json":
        rendered = json.dumps(report, indent=2)
    elif args.format == "md":
        rendered = render_markdown(report)
    elif args.format == "csv":
        rendered = render_csv(report)
    elif args.format == "html":
        rendered = render_html(report)
    else:
        rendered = render_table(report, only_matches=args.only_matches, use_color=not args.no_color)

    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
        print(f"Report written to {args.output}")
    else:
        print(rendered)

    if args.sqlite:
        scan_id = save_to_sqlite(args.sqlite, report)
        print(f"Saved scan #{scan_id} to {args.sqlite}")

    if args.diff:
        prev = json.loads(args.diff.read_text(encoding="utf-8"))
        changes = diff_reports(prev, report)
        print("Diff summary:")
        for line in changes or ["No changes detected."]:
            print(f"  {line}")

    total_matches = sum(len(r.get("matches", [])) for r in report["results"])
    if args.fail_on_findings and total_matches > 0:
        return 1
    return 0
