import socket
import threading


class LocalMockServices:
    """Starts temporary loopback TCP services for safe offline testing."""

    def __init__(self, host: str = "127.0.0.1") -> None:
        self.host = host
        self._servers: list[socket.socket] = []
        self._stop = threading.Event()
        self.ports: dict[str, int] = {}

    def start(self) -> dict[str, int]:
        banners = {
            "ssh": b"SSH-2.0-OpenSSH_8.2p1 Ubuntu-4ubuntu0.5\r\n",
            "http": (
                b"HTTP/1.1 200 OK\r\n"
                b"Server: nginx/1.18.0\r\n"
                b"Content-Length: 2\r\n\r\nOK"
            ),
        }
        for name, payload in banners.items():
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((self.host, 0))
            srv.listen(5)
            srv.settimeout(0.2)
            self.ports[name] = srv.getsockname()[1]
            self._servers.append(srv)
            t = threading.Thread(target=self._serve, args=(srv, payload), daemon=True)
            t.start()
        return self.ports

    def _serve(self, srv: socket.socket, payload: bytes) -> None:
        while not self._stop.is_set():
            try:
                conn, _ = srv.accept()
            except TimeoutError:
                continue
            except OSError:
                break
            with conn:
                try:
                    conn.settimeout(0.2)
                    try:
                        conn.recv(256)
                    except TimeoutError:
                        pass
                    conn.sendall(payload)
                except OSError:
                    pass

    def stop(self) -> None:
        self._stop.set()
        for srv in self._servers:
            try:
                srv.close()
            except OSError:
                pass
