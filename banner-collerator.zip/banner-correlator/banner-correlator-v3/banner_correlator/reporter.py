import csv
import html
import io
import json
from typing import Any


def mask_host(host: str) -> str:
    if "." in host:
        parts = host.split(".")
        if len(parts) == 4:
            return f"{parts[0]}.{parts[1]}.x.x"
    return host[:4] + "***"


def render_table(report: dict[str, Any], only_matches: bool = False, use_color: bool = True) -> str:
    c_reset = "\033[0m" if use_color else ""
    c_bold = "\033[1m" if use_color else ""
    c_warn = "\033[33m" if use_color else ""
    c_ok = "\033[32m" if use_color else ""

    lines = [
        f"{c_bold}Audit Report{c_reset} | Generated: {report['generated_at']} | Hygiene Score: {report['hygiene_score']}/100",
        f"{'HOST':<18} {'PORT':<7} {'STATE':<10} {'RTT(ms)':<9} {'SERVICE':<18} {'FINDINGS':<9} BANNER",
        "-" * 96,
    ]
    for item in report["results"]:
        if only_matches and not item.get("matches") and item.get("state") != "open":
            continue
        if only_matches and not item.get("matches") and not item.get("recommendations"):
            continue
        state_col = f"{c_ok}{item['state']}{c_reset}" if item["state"] == "open" else item["state"]
        rtt = str(item["rtt_ms"]) if item.get("rtt_ms") is not None else "-"
        svc = item.get("detected") or "-"
        f_count = len(item.get("matches", []))
        banner = (item.get("banner") or "")[:40]
        lines.append(
            f"{item['host']:<18} {item['port']:<7} {state_col:<10} {rtt:<9} {svc:<18} {f_count:<9} {banner}"
        )
        for m in item.get("matches", []):
            lines.append(
                f"   {c_warn}[{m['severity'].upper()}]{c_reset} {m['reference']} ({m['reason']}): {m['summary']}"
            )
    return "\n".join(lines)


def render_markdown(report: dict[str, Any]) -> str:
    out = [
        "# Authorized Asset & Banner Audit Report",
        f"- **Generated At:** {report['generated_at']}",
        f"- **Targets Checked:** {report['targets_checked']}",
        f"- **Hygiene Score:** {report['hygiene_score']}/100",
        "",
        "| Host | Port | Protocol | State | Service | Findings |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for item in report["results"]:
        svc = item.get("detected") or "-"
        findings = ", ".join(m["reference"] for m in item.get("matches", [])) or "None"
        out.append(
            f"| `{item['host']}` | {item['port']} | {item.get('protocol', 'tcp')} | {item['state']} | {svc} | {findings} |"
        )
    return "\n".join(out) + "\n"


def render_csv(report: dict[str, Any]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["host", "port", "protocol", "state", "rtt_ms", "detected", "findings", "banner"])
    for item in report["results"]:
        findings = ";".join(m["reference"] for m in item.get("matches", []))
        writer.writerow([
            item["host"],
            item["port"],
            item.get("protocol", "tcp"),
            item["state"],
            item.get("rtt_ms", ""),
            item.get("detected", ""),
            findings,
            item.get("banner", ""),
        ])
    return buf.getvalue()


def render_html(report: dict[str, Any]) -> str:
    rows = []
    for item in report["results"]:
        findings = ", ".join(m["reference"] for m in item.get("matches", [])) or "-"
        rows.append(
            f"<tr><td>{html.escape(str(item['host']))}</td>"
            f"<td>{item['port']}</td>"
            f"<td>{html.escape(str(item['state']))}</td>"
            f"<td>{html.escape(str(item.get('detected') or '-'))}</td>"
            f"<td>{html.escape(findings)}</td>"
            f"<td><code>{html.escape(str(item.get('banner') or ''))}</code></td></tr>"
        )
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Banner Correlator Report</title>
<style>body{{font-family:sans-serif;margin:2rem;background:#0f172a;color:#e2e8f0}}
table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #334155;padding:8px;text-align:left}}
th{{background:#1e293b}}</style></head>
<body><h1>Banner Correlator Audit Report</h1>
<p>Generated: {html.escape(report['generated_at'])} | Hygiene Score: {report['hygiene_score']}/100</p>
<table><thead><tr><th>Host</th><th>Port</th><th>State</th><th>Service</th><th>Findings</th><th>Banner</th></tr></thead>
<tbody>{''.join(rows)}</tbody></table></body></html>"""


def diff_reports(previous: dict[str, Any], current: dict[str, Any]) -> list[str]:
    prev_map = {(r["host"], r["port"]): r for r in previous.get("results", [])}
    curr_map = {(r["host"], r["port"]): r for r in current.get("results", [])}
    changes: list[str] = []
    for key in sorted(set(prev_map) | set(curr_map)):
        if key not in prev_map:
            changes.append(f"+ Added {key[0]}:{key[1]} ({curr_map[key]['state']})")
        elif key not in curr_map:
            changes.append(f"- Removed {key[0]}:{key[1]}")
        else:
            old_r, new_r = prev_map[key], curr_map[key]
            if old_r.get("state") != new_r.get("state"):
                changes.append(f"~ {key[0]}:{key[1]} state: {old_r.get('state')} -> {new_r.get('state')}")
            if old_r.get("banner") != new_r.get("banner"):
                changes.append(f"~ {key[0]}:{key[1]} banner changed: {old_r.get('banner')!r} -> {new_r.get('banner')!r}")
    return changes
