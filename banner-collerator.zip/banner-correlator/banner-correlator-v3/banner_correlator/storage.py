import json
import sqlite3
from pathlib import Path
from typing import Any


def save_to_sqlite(db_path: Path, report: dict[str, Any]) -> int:
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                generated_at TEXT NOT NULL,
                targets_checked INTEGER NOT NULL,
                hygiene_score INTEGER NOT NULL,
                report_json TEXT NOT NULL
            )
            """
        )
        cur = conn.execute(
            "INSERT INTO scans (generated_at, targets_checked, hygiene_score, report_json) VALUES (?, ?, ?, ?)",
            (
                report["generated_at"],
                report["targets_checked"],
                report["hygiene_score"],
                json.dumps(report),
            ),
        )
        conn.commit()
        return int(cur.lastrowid)
    finally:
        conn.close()
