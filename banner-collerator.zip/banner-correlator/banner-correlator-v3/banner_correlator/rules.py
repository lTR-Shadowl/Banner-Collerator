import json
import operator
from pathlib import Path
from typing import Any
from .parsers import detect_product, normalize_tuple, parse_version_tuple

OPERATORS = {
    "<": operator.lt,
    "<=": operator.le,
    "==": operator.eq,
    "!=": operator.ne,
    ">=": operator.ge,
    ">": operator.gt,
}

SEVERITY_WEIGHTS = {
    "critical": 25,
    "high": 15,
    "medium": 8,
    "low": 3,
    "info": 1,
}


def load_rules(rule_paths: list[Path]) -> list[dict[str, Any]]:
    loaded: list[dict[str, Any]] = []
    for path in rule_paths:
        if not path.exists():
            raise FileNotFoundError(f"Rules file not found: {path}")
        raw_list = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw_list, list):
            raise ValueError(f"Rules file must be a JSON array: {path}")
        for item in raw_list:
            if not isinstance(item, dict):
                continue
            product = str(item.get("product", "")).strip()
            op_str = str(item.get("operator", "<")).strip()
            ver_raw = item.get("version", item.get("affected_below"))
            if not product or ver_raw is None:
                continue
            if op_str not in OPERATORS:
                raise ValueError(f"Unsupported rule operator {op_str!r} in {path}")
            if isinstance(ver_raw, list):
                ver_tuple = tuple(int(x) for x in ver_raw)
            else:
                ver_tuple = parse_version_tuple(str(ver_raw))
            loaded.append({
                "product": product,
                "operator": op_str,
                "version_tuple": ver_tuple,
                "version_str": ".".join(str(x) for x in ver_tuple),
                "severity": str(item.get("severity", "medium")).lower(),
                "cvss": float(item.get("cvss", 0.0)),
                "reference": str(item.get("reference", "ADVISORY")),
                "summary": str(item.get("summary", "")),
                "remediation": str(item.get("remediation", "Review vendor patch guidance.")),
            })
    return loaded


def is_ignored(host: str, port: int, reference: str, ignore_list: list[dict[str, Any]]) -> bool:
    for entry in ignore_list:
        h_ok = entry.get("host") in (None, "*", host)
        p_ok = entry.get("port") in (None, "*", port)
        r_ok = entry.get("reference") in (None, "*", reference)
        if h_ok and p_ok and r_ok:
            return True
    return False


def evaluate_findings(
    host: str,
    port: int,
    banner: str,
    http_info: dict[str, Any],
    tls_info: dict[str, Any],
    rules: list[dict[str, Any]],
    ignore_list: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    ignores = ignore_list or []
    detected = detect_product(banner)
    matches: list[dict[str, Any]] = []
    recommendations: list[str] = []

    if detected and detected["version_tuple"]:
        prod = detected["product"]
        norm_detected = normalize_tuple(detected["version_tuple"])
        for rule in rules:
            if rule["product"].lower() != prod.lower():
                continue
            if is_ignored(host, port, rule["reference"], ignores):
                continue
            cmp_fn = OPERATORS[rule["operator"]]
            if cmp_fn(norm_detected, normalize_tuple(rule["version_tuple"])):
                matches.append({
                    "reference": rule["reference"],
                    "severity": rule["severity"],
                    "cvss": rule["cvss"],
                    "reason": f"{prod} {detected['raw_version']} {rule['operator']} {rule['version_str']}",
                    "summary": rule["summary"],
                    "remediation": rule["remediation"],
                })
                if rule["remediation"] not in recommendations:
                    recommendations.append(rule["remediation"])

    if http_info.get("is_http"):
        if http_info.get("disclosures"):
            recommendations.append("Suppress HTTP Server/X-Powered-By version headers.")
        if http_info.get("missing_security_headers"):
            recommendations.append(
                "Add missing HTTP security headers: " + ", ".join(http_info["missing_security_headers"])
            )

    if tls_info.get("enabled") and tls_info.get("expired"):
        recommendations.append("Renew expired TLS certificate immediately.")

    detected_label = (
        f"{detected['product']} {detected['raw_version']}" if detected else None
    )
    return {
        "detected": detected_label,
        "matches": matches,
        "recommendations": recommendations,
    }


def compute_hygiene_score(results: list[dict[str, Any]]) -> int:
    penalty = 0
    for item in results:
        for m in item.get("matches", []):
            penalty += SEVERITY_WEIGHTS.get(m.get("severity", "medium"), 5)
        tls = item.get("tls", {})
        if tls.get("enabled") and tls.get("expired"):
            penalty += 20
        http = item.get("http", {})
        if http.get("is_http"):
            penalty += min(6, len(http.get("missing_security_headers", [])))
    return max(0, 100 - penalty)
