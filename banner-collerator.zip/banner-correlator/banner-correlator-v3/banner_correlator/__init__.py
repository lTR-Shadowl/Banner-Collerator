"""Banner Correlator - Authorized Asset Inventory & Hygiene Auditor."""

__version__ = "0.3.0"
