import ipaddress
import json
import re
from pathlib import Path
from typing import Any

PORT_PROFILES: dict[str, str] = {
    "web": "80,443,8000,8080,8443",
    "ssh-ftp": "21,22,2222",
    "mail": "25,110,143,465,587,993,995",
    "db": "3306,5432,6379,27017",
    "common": "21,22,25,53,80,110,143,443,465,587,993,995,3306,5432,6379,8080,8443",
}


def load_config(config_path: Path | None) -> dict[str, Any]:
    if not config_path:
        return {}
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    data = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Configuration file must contain a JSON object.")
    return data


def expand_targets(
    raw_hosts: list[str] | None = None,
    targets_file: Path | None = None,
    max_cidr_hosts: int = 256,
) -> list[str]:
    tokens: list[str] = []
    if raw_hosts:
        for item in raw_hosts:
            tokens.extend(part.strip() for part in item.split(",") if part.strip())
    if targets_file:
        if not targets_file.exists():
            raise FileNotFoundError(f"Targets file not found: {targets_file}")
        for line in targets_file.read_text(encoding="utf-8").splitlines():
            clean = line.split("#", 1)[0].strip()
            if clean:
                tokens.append(clean)

    if not tokens:
        raise ValueError("At least one target host, CIDR, or targets file is required.")

    targets: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if "/" in token:
            net = ipaddress.ip_network(token, strict=False)
            hosts = list(net.hosts()) if net.num_addresses > 2 else [net.network_address]
            if len(hosts) > max_cidr_hosts:
                raise ValueError(
                    f"CIDR {token} expands to {len(hosts)} hosts (limit {max_cidr_hosts})."
                )
            for addr in hosts:
                s = str(addr)
                if s not in seen:
                    seen.add(s)
                    targets.append(s)
        else:
            validated = validate_host(token)
            if validated not in seen:
                seen.add(validated)
                targets.append(validated)
    return targets


def validate_host(host: str) -> str:
    cleaned = host.strip().strip("[]")
    if not cleaned:
        raise ValueError("Host cannot be empty.")
    try:
        ipaddress.ip_address(cleaned)
        return cleaned
    except ValueError:
        pass
    if re.fullmatch(r"[A-Za-z0-9.-]{1,253}", cleaned) and ".." not in cleaned:
        return cleaned
    raise ValueError(f"Invalid host or IP address: {host!r}")


def parse_ports(raw_ports: str | None, profile: str | None = None) -> list[int]:
    spec = PORT_PROFILES[profile] if profile else (raw_ports or "22,80")
    ports: list[int] = []
    seen: set[int] = set()
    for token in spec.split(","):
        item = token.strip()
        if not item:
            continue
        if "-" in item:
            start_s, end_s = item.split("-", 1)
            start, end = int(start_s), int(end_s)
            if start > end:
                raise ValueError(f"Invalid port range: {item!r}")
            candidates = range(start, end + 1)
        else:
            candidates = [int(item)]
        for port in candidates:
            if not (1 <= port <= 65535):
                raise ValueError(f"Port out of range (1-65535): {port}")
            if port not in seen:
                seen.add(port)
                ports.append(port)
    if not ports:
        raise ValueError("No valid ports specified.")
    return ports
