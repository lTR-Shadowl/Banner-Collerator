import asyncio
import random
import socket
import ssl
import time
from datetime import datetime, timezone
from typing import Any
from .parsers import analyze_http_headers, format_banner_preview

HTTP_PORTS = {80, 8000, 8080, 8888}
TLS_PORTS = {443, 8443, 993, 995, 465}


def build_tcp_probe(port: int, host: str) -> bytes | None:
    if port in HTTP_PORTS or port in TLS_PORTS:
        return (
            f"HEAD / HTTP/1.1\r\nHost: {host}\r\n"
            f"User-Agent: BannerCorrelator-Audit/0.3\r\nConnection: close\r\n\r\n"
        ).encode("ascii", errors="ignore")
    if port == 6379:
        return b"INFO server\r\n"
    return None


def inspect_tls_sync(host: str, port: int, timeout: float) -> dict[str, Any]:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((host, port), timeout=timeout) as raw_sock:
            with ctx.wrap_socket(raw_sock, server_hostname=host) as tls_sock:
                cipher = tls_sock.cipher()
                version = tls_sock.version()
                der_cert = tls_sock.getpeercert(binary_form=True)
                cert_dict = tls_sock.getpeercert() or {}
                not_after = cert_dict.get("notAfter")
                expired = False
                if not_after:
                    exp_dt = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(
                        tzinfo=timezone.utc
                    )
                    expired = exp_dt < datetime.now(timezone.utc)
                return {
                    "enabled": True,
                    "tls_version": version,
                    "cipher": cipher[0] if cipher else None,
                    "not_after": not_after,
                    "expired": expired,
                    "cert_bytes": len(der_cert) if der_cert else 0,
                }
    except Exception as exc:
        return {"enabled": False, "error": str(exc)}


async def probe_tcp_port(
    host: str,
    port: int,
    timeout: float = 2.0,
    jitter_ms: int = 0,
    max_bytes: int = 4096,
) -> dict[str, Any]:
    if jitter_ms > 0:
        await asyncio.sleep(random.uniform(0, jitter_ms / 1000.0))

    start = time.perf_counter()
    use_tls = port in TLS_PORTS
    ssl_ctx = None
    if use_tls:
        ssl_ctx = ssl.create_default_context()
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE

    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port, ssl=ssl_ctx, server_hostname=host if use_tls else None),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        return {"port": port, "protocol": "tcp", "state": "timeout", "rtt_ms": None, "banner": ""}
    except ConnectionRefusedError:
        return {"port": port, "protocol": "tcp", "state": "closed", "rtt_ms": None, "banner": ""}
    except OSError as exc:
        return {"port": port, "protocol": "tcp", "state": "error", "error": str(exc), "rtt_ms": None, "banner": ""}

    rtt_ms = round((time.perf_counter() - start) * 1000, 2)
    chunks: list[bytes] = []
    try:
        probe = build_tcp_probe(port, host)
        if probe:
            writer.write(probe)
            await asyncio.wait_for(writer.drain(), timeout=timeout)

        total = 0
        while total < max_bytes:
            try:
                chunk = await asyncio.wait_for(reader.read(min(1024, max_bytes - total)), timeout=timeout)
            except asyncio.TimeoutError:
                break
            if not chunk:
                break
            chunks.append(chunk)
            total += len(chunk)
            if b"\n" in chunk and port not in HTTP_PORTS and port not in TLS_PORTS:
                break
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

    raw_bytes = b"".join(chunks)
    raw_text = raw_bytes.decode("utf-8", errors="replace")
    banner, hex_preview = format_banner_preview(raw_bytes)
    http_info = analyze_http_headers(raw_text)
    tls_info = await asyncio.to_thread(inspect_tls_sync, host, port, timeout) if use_tls else {"enabled": False}

    return {
        "port": port,
        "protocol": "tcp",
        "state": "open",
        "rtt_ms": rtt_ms,
        "banner": banner,
        "hex_preview": hex_preview,
        "http": http_info,
        "tls": tls_info,
    }


def probe_udp_port_sync(host: str, port: int, timeout: float = 1.5) -> dict[str, Any]:
    payload = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x07version\x04bind\x00\x00\x10\x00\x03" if port == 53 else b"\r\n"
    start = time.perf_counter()
    sock = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        sock.sendto(payload, (host, port))
        data, _ = sock.recvfrom(1024)
        rtt_ms = round((time.perf_counter() - start) * 1000, 2)
        banner, hex_preview = format_banner_preview(data)
        return {
            "port": port,
            "protocol": "udp",
            "state": "open",
            "rtt_ms": rtt_ms,
            "banner": banner,
            "hex_preview": hex_preview,
            "http": {"is_http": False},
            "tls": {"enabled": False},
        }
    except TimeoutError:
        return {"port": port, "protocol": "udp", "state": "open|filtered", "rtt_ms": None, "banner": ""}
    except OSError as exc:
        return {"port": port, "protocol": "udp", "state": "closed", "error": str(exc), "rtt_ms": None, "banner": ""}
    finally:
        sock.close()
