import json
import tempfile
import unittest
from pathlib import Path

from banner_correlator.cli import main
from banner_correlator.config import expand_targets, parse_ports
from banner_correlator.mock_server import LocalMockServices
from banner_correlator.parsers import analyze_http_headers, detect_product
from banner_correlator.reporter import diff_reports
from banner_correlator.rules import evaluate_findings, load_rules


class TestBannerCorrelator(unittest.TestCase):
    def test_port_parsing_and_profiles(self):
        self.assertEqual(parse_ports("22,80,8000-8002"), [22, 80, 8000, 8001, 8002])
        self.assertIn(443, parse_ports(None, profile="web"))
        with self.assertRaises(ValueError):
            parse_ports("9000-8000")

    def test_target_expansion_cidr(self):
        hosts = expand_targets(["192.168.1.0/30"])
        self.assertEqual(hosts, ["192.168.1.1", "192.168.1.2"])

    def test_product_and_http_hygiene(self):
        det = detect_product("SSH-2.0-OpenSSH_8.2p1 Ubuntu")
        self.assertEqual(det["product"], "OpenSSH")
        self.assertEqual(det["version_tuple"], (8, 2, 1))

        http = analyze_http_headers("HTTP/1.1 200 OK\r\nServer: nginx/1.18.0\r\n\r\n")
        self.assertTrue(http["is_http"])
        self.assertIn("server", http["disclosures"])
        self.assertIn("strict-transport-security", http["missing_security_headers"])

    def test_rule_evaluation_and_ignore(self):
        rules = load_rules([Path(__file__).resolve().parent.parent / "cve_rules.json"])
        res = evaluate_findings(
            "127.0.0.1", 22, "SSH-2.0-OpenSSH_8.2p1", {"is_http": False}, {"enabled": False}, rules
        )
        self.assertEqual(len(res["matches"]), 1)
        ignored = evaluate_findings(
            "127.0.0.1",
            22,
            "SSH-2.0-OpenSSH_8.2p1",
            {"is_http": False},
            {"enabled": False},
            rules,
            ignore_list=[{"host": "127.0.0.1", "port": 22, "reference": "ADVISORY-SSH-001"}],
        )
        self.assertEqual(len(ignored["matches"]), 0)

    def test_end_to_end_mock_scan_and_diff(self):
        mock = LocalMockServices()
        ports = mock.start()
        try:
            with tempfile.TemporaryDirectory() as tmp:
                out1 = Path(tmp) / "r1.json"
                db = Path(tmp) / "history.sqlite"
                rc = main([
                    "--host", "127.0.0.1",
                    "--ports", f"{ports['ssh']},{ports['http']}",
                    "--format", "json",
                    "--output", str(out1),
                    "--sqlite", str(db),
                ])
                self.assertEqual(rc, 0)
                data = json.loads(out1.read_text(encoding="utf-8"))
                self.assertEqual(len(data["results"]), 2)
                self.assertEqual(diff_reports(data, data), [])
        finally:
            mock.stop()


if __name__ == "__main__":
    unittest.main()
