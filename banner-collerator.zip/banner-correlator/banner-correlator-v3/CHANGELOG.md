# Changelog

## [0.3.0] - 2026-11-23
- Modularized codebase into `banner_correlator` package (`cli`, `scanner`, `parsers`, `rules`, `reporter`, `storage`, `config`, `mock_server`).
- Added asynchronous TCP/TLS/UDP inspection with configurable concurrency, jitter, IPv4/IPv6, CIDR expansion, and target files.
- Added TLS handshake and X.509 certificate metadata inspection with expiration alerts.
- Added HTTP security header hygiene checks and server disclosure analysis.
- Added operator-based version rules (`<`, `<=`, `==`, `>=`, `>`), severity levels, ignore filters, and hardening recommendations.
- Added JSON, Markdown, CSV, HTML, and terminal table reporting plus scan diffing (`--diff`) and SQLite history persistence.
- Added unit tests, mock test server utility, and GitHub Actions CI workflow.
